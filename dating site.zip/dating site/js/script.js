$(document).ready(function(){
    let position=0;
    const slidesToShow=2;
    const slidesToScroll=2;
    const conteiner=$('.conteiner-testimonials__slider');
    const track=$('.testimonials-slider-track');
    const item=$('.testimonials-slider-item');
    const btnPrev=$('.button-prev');
    const btnNext=$('.button-next');
    const itemsCount=item.length;
    const itemWidth=conteiner.width()/slidesToShow;
    const movePosition=slidesToScroll*itemWidth;
    item.each(function(index, item){
        $(item).css({
            minWidth: itemWidth,
        })
    });
    btnNext.click(function(){
        const itemsLeft = itemsCount -(Math.abs(position)+slidesToShow*itemWidth)/itemWidth;
        position-=itemsLeft>=slidesToScroll?movePosition:itemsLeft*itemWidth;
        setPosition();
        checkBtns();
    });
    btnPrev.click(function(){
        const itemsLeft = Math.abs(position)/itemWidth;
        position+=itemsLeft>=slidesToScroll?movePosition:itemsLeft*itemWidth;
        setPosition();
        checkBtns();
    });
    const setPosition = ()=>{
        track.css({
            transform: `translateX(${position}px)`
        });
    };
    const checkBtns = ()=>{
        btnPrev.prop('disabled', position === 0);
        btnNext.prop(
            'disabled', 
            position<=-(itmesCount-slidesToShow)*itemWidth
        );
    };
    checkBtns();
});
